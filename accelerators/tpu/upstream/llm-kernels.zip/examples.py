from math import exp, log, sqrt, ceil, log2, isclose

from bisect import bisect_right

def close(got, expected):
    if isinstance(expected, (list, tuple)):
        assert len(got) == len(expected), (got, expected)
        for actual, wanted in zip(got, expected):
            close(actual, wanted)
    else:
        assert isclose(got, expected, rel_tol=1e-5, abs_tol=1e-5), (got, expected)

def norm(v):
    length = sqrt(sum(x*x for x in v)+1e-6)
    return [x/length for x in v]

def delta(state, gamma, k, q, v, beta):
    decayed = [x*g for x,g in zip(state,gamma)]
    prediction = sum(x*y for x,y in zip(decayed,k))
    write = beta*(v-prediction)
    next_state = [x+ki*write for x,ki in zip(decayed,k)]
    return next_state, sum(x*qi for x,qi in zip(next_state,q))

def convolution():
    state = [2,3]
    outputs = []
    saved = []
    for token in (5,7):
        window = state+[token]
        outputs.append(sum(x*w for x,w in zip(window,[1,2,-1])))
        state = window[1:]
        saved.append(state)
    close(outputs,[3,6])
    close(saved,[[3,5],[5,7]])
    return outputs,saved

def test_conv_window():
    outputs,states=convolution()
    close([states[min(i,1-1)] for i in range(2)],[[3,5],[3,5]])

def test_delta_decode():
    q,k=norm([1]),norm([1])
    first,out=delta([2],[.5],k,q,5,.5)
    second,padded=delta(first,[1],[0],[0],0,0)
    close([out,padded],[3,0])
    close([first,second],[[3],[3]])

if __name__ == "__main__":
    test_conv_window()
    test_delta_decode()
    print("2 examples passed")
