from math import exp, log, sqrt, ceil, log2, isclose

from bisect import bisect_right

def close(got, expected):
    if isinstance(expected, (list, tuple)):
        assert len(got) == len(expected), (got, expected)
        for actual, wanted in zip(got, expected):
            close(actual, wanted)
    else:
        assert isclose(got, expected, rel_tol=1e-5, abs_tol=1e-5), (got, expected)

def delta(state, gamma, k, q, v, beta):
    decayed = [x*g for x,g in zip(state,gamma)]
    prediction = sum(x*y for x,y in zip(decayed,k))
    write = beta*(v-prediction)
    next_state = [x+ki*write for x,ki in zip(decayed,k)]
    return next_state, sum(x*qi for x,qi in zip(next_state,q))

def convolution():
    state = [2,3]
    outputs = []
    saved = []
    for token in (5,7):
        window = state+[token]
        outputs.append(sum(x*w for x,w in zip(window,[1,2,-1])))
        state = window[1:]
        saved.append(state)
    close(outputs,[3,6])
    close(saved,[[3,5],[5,7]])
    return outputs,saved

def test_conv_update():
    convolution()

def test_recurrent_state():
    close(delta([2,4],[.5,.5],[1,1],[0,1],5,.5),([2,3],3))

if __name__ == "__main__":
    test_conv_update()
    test_recurrent_state()
    print("2 examples passed")
